import{r}from"./vendor-ui-BXMHw-UQ.js";import{s as c,p as s,f as t}from"./index-BNKLZVi9.js";function a(e){return r.useSyncExternalStore(c,s,s),t(e)}export{a as u};
