const e=""+new URL("LoginLightModeHeader-BHWFo69e.svg",import.meta.url).href;export{e as l};
