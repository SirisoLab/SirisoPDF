import{r}from"./vendor-ui-C39r5IFY.js";import{s as c,p as s,f as t}from"./index-Bv8tgX6R.js";function a(e){return r.useSyncExternalStore(c,s,s),t(e)}export{a as u};
